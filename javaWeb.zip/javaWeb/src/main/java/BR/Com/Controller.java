package BR.Com;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Registro
		String nome = request.getParameter("name");
		String senhaCadastro = request.getParameter("senha");
		String email = request.getParameter("email");
		String repetirSenha = request.getParameter("repetirSenha");
		
		
		//Login
		
		String login = request.getParameter("Login");
		String senhaLogin = request.getParameter("Senha");
		
		if(login.equals("arlon@gmail.com") && senhaLogin.equals("123")) {
			request.setAttribute("Login", login);
			RequestDispatcher rd = request.getRequestDispatcher("html.jsp");
			rd.forward(request, response);
		}else {
			request.setAttribute("invalido", "login ou senha invalido");
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		
	}

}
